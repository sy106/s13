# from django.utils.text import (
#     Truncator, normalize_newlines, phone2numeric, slugify as _slugify, wrap,
# )
#
#
# v = Truncator("hello sfs asdfl asdf asdf").words(2, truncate=' ...')
# print(v)


# import requests
#
#
# requests.get('http://127.0.0.1:8000/index/',)