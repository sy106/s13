from django.apps import AppConfig


class OpenstackConfig(AppConfig):
    name = 'openstack'
