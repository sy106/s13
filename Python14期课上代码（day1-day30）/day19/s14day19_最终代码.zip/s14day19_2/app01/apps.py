from django.apps import AppConfig


class App01Config(AppConfig):
    name = 'app01'
