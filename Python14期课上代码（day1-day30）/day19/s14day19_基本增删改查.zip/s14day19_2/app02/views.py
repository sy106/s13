from django.shortcuts import render,HttpResponse

# Create your views here.


def login(request):
    return HttpResponse('APP02,login')