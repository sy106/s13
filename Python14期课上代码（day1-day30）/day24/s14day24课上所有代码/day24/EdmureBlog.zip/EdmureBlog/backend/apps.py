from django.apps import AppConfig


class BackstageConfig(AppConfig):
    name = 'backend'
